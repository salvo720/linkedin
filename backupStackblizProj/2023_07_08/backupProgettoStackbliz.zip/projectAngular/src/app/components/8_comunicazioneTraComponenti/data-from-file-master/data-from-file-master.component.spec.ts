import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DataFromFileMasterComponent } from './data-from-file-master.component';

describe('DataFromFileMasterComponent', () => {
  let component: DataFromFileMasterComponent;
  let fixture: ComponentFixture<DataFromFileMasterComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DataFromFileMasterComponent]
    });
    fixture = TestBed.createComponent(DataFromFileMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
