import { Component, EventEmitter, Output } from '@angular/core';
import IFileItem from '../../../../../../../projectAngular/src/app/interfaces/IFileItem';

@Component({
  selector: 'app-file-group',
  templateUrl: './file-group.component.html',
  styleUrls: ['./file-group.component.scss'],
})
export class FileGroupComponent {
  @Output() eventFileGroup = new EventEmitter<IFileItem>();

  emitEventFileGroup(dataFormItem: IFileItem) {
    console.log('data in fileGroup Form fileItem:', dataFormItem);
    this.eventFileGroup.emit(dataFormItem);
  }
}
