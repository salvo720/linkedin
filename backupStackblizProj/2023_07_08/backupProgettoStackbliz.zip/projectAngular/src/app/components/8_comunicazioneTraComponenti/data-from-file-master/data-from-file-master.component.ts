import { Component, Input } from '@angular/core';
import IFileItem from '../../../../../../projectAngular/src/app/interfaces/IFileItem';

@Component({
  selector: 'app-data-from-file-master',
  templateUrl: './data-from-file-master.component.html',
  styleUrls: ['./data-from-file-master.component.scss'],
})
export class DataFromFileMasterComponent {
  @Input() dataFromFile!: IFileItem;
}
