import { Component, EventEmitter, Output } from '@angular/core';
import IFileItem from '../../../../../../projectAngular/src/app/interfaces/IFileItem';

@Component({
  selector: 'app-file-master',
  templateUrl: './file-master.component.html',
  styleUrls: ['./file-master.component.scss'],
})
export class FileMasterComponent {
  data!: IFileItem;
  emitEventFileMaster(dataFormItem: IFileItem) {
    console.log('dataForm group > Item:', dataFormItem);
    console.log('data in fileMaster Form fileGroup:', dataFormItem);
    this.data = dataFormItem;
  }
}
