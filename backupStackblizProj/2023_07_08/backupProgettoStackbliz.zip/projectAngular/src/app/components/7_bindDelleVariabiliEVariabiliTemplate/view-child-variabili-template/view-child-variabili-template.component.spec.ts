import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewChildVariabiliTemplateComponent } from './view-child-variabili-template.component';

describe('ViewChildVariabiliTemplateComponent', () => {
  let component: ViewChildVariabiliTemplateComponent;
  let fixture: ComponentFixture<ViewChildVariabiliTemplateComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ViewChildVariabiliTemplateComponent]
    });
    fixture = TestBed.createComponent(ViewChildVariabiliTemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
