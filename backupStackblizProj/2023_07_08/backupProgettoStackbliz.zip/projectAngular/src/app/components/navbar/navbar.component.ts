import { Component, ElementRef, HostListener, ViewChild } from '@angular/core';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss'],
})
export class NavbarComponent {
  isCollapsed: boolean = true;
  isOpenDrop1: boolean = false;
  isOpenDrop2: boolean = false;

  // openDropdown(idDropdown: string) {
  //   this.closeDropdown();
  //   console.log(document.getElementById(idDropdown));
  //   document.getElementById(idDropdown)?.classList.toggle('show');
  // }

  closeDropdown(): void {
    this.isOpenDrop1 = false;
    this.isOpenDrop2 = false;
  }

  toggleCollapse(): void {
    this.isCollapsed = !this.isCollapsed;
  }

  toggleDropdown(dropdownName: string): void {
    this.closeDropdown();
    if ('isOpenDrop1' == dropdownName) this.isOpenDrop1 = !this.isOpenDrop1;
    else if ('isOpenDrop2' == dropdownName)
      this.isOpenDrop2 = !this.isOpenDrop2;
  }

  // aggiungere event lister al click su document o su un li>a che chiude i dropdown
}
