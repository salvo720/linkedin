import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { FormsModule } from '@angular/forms';
import { ErrorComponent } from './components/error/error.component';
import { HomeComponent } from './components/home/home.component';
import { RouterModule } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ServersComponent } from './components/6_decoratoreComponentEAttributoSelecotor/servers/servers.component';
import { ServerComponent } from './components/6_decoratoreComponentEAttributoSelecotor/servers/server/server.component';
import { Server2Component } from './components/6_decoratoreComponentEAttributoSelecotor/servers/server2/server2.component';
import { ViewChildVariabiliTemplateComponent } from './components/7_bindDelleVariabiliEVariabiliTemplate/view-child-variabili-template/view-child-variabili-template.component';
import { FileMasterComponent } from './components/8_comunicazioneTraComponenti/file-master/file-master.component';
import { DataFromFileMasterComponent } from './components/8_comunicazioneTraComponenti/data-from-file-master/data-from-file-master.component';
import { FileGroupComponent } from '../../../projectAngular/src/app/components/8_comunicazioneTraComponenti/file-master/file-group/file-group.component';
import { FileItemComponent } from '../../../projectAngular/src/app/components/8_comunicazioneTraComponenti/file-master/file-group/file-item/file-item.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { CittaComponent } from './components/11_forVsReduce/citta/citta.component';

@NgModule({
  declarations: [
    AppComponent,
    ServerComponent,
    ServersComponent,
    Server2Component,
    ErrorComponent,
    HomeComponent,
    ViewChildVariabiliTemplateComponent,
    FileGroupComponent,
    FileItemComponent,
    FileMasterComponent,
    DataFromFileMasterComponent,
    NavbarComponent,
    CittaComponent,
  ],
  imports: [BrowserModule, FormsModule, RouterModule, AppRoutingModule],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
