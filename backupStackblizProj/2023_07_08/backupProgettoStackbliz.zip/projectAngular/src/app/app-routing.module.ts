import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from '../app/components/home/home.component';
import { ErrorComponent } from '../app/components/error/error.component';
import { ViewChildVariabiliTemplateComponent } from '../../../projectAngular/src/app/components/7_bindDelleVariabiliEVariabiliTemplate/view-child-variabili-template/view-child-variabili-template.component';
import { ServersComponent } from '../../../projectAngular/src/app/components/6_decoratoreComponentEAttributoSelecotor/servers/servers.component';
import { FileMasterComponent } from '../../../projectAngular/src/app/components/8_comunicazioneTraComponenti/file-master/file-master.component';
import { CittaComponent } from '../../../projectAngular/src/app/components/11_forVsReduce/citta/citta.component';

const routes: Routes = [
  { title: 'Pagina Home', path: '', component: HomeComponent },
  { title: 'Home redirect', path: 'home', redirectTo: '' },
  {
    title: 'Pagina servers',
    path: 'server',
    component: ServersComponent,
  },
  {
    title: 'variable template',
    path: 'vartemp',
    component: ViewChildVariabiliTemplateComponent,
  },
  {
    title: 'variable template',
    path: 'variable template',
    redirectTo: 'vartem',
  },
  {
    title: 'file master',
    path: 'filemaster',
    component: FileMasterComponent,
  },
  {
    title: ' for vs reduce',
    path: 'reducejs',
    component: CittaComponent,
  },
  { title: '404 - Page not found', path: '**', component: ErrorComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
