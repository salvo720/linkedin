export default interface IFileItem {
  name: string;
  containtsFile: string;
}
