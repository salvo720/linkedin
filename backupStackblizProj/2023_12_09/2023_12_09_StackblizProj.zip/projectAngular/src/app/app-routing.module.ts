import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from '../app/components/home/home.component';
import { ErrorComponent } from '../app/components/error/error.component';
import { ViewChildVariabiliTemplateComponent } from '../../../projectAngular/src/app/components/7_bindDelleVariabiliEVariabiliTemplate/view-child-variabili-template/view-child-variabili-template.component';
import { ServersComponent } from '../../../projectAngular/src/app/components/6_decoratoreComponentEAttributoSelecotor/servers/servers.component';
import { FileMasterComponent } from '../../../projectAngular/src/app/components/8_comunicazioneTraComponenti/file-master/file-master.component';
import { CittaComponent } from '../../../projectAngular/src/app/components/12_forVsReduce/citta/citta.component';
import { LayoutComponent } from '../../../projectAngular/src/app/components/domandeTecniche/2_css3/layout/layout.component';
import { CssRobustoComponent } from '../../../projectAngular/src/app/components/domandeTecniche/3_css3/css-robusto/css-robusto.component';
import { FormComponent } from '../../../projectAngular/src/app/components/13_form/form/form.component';
import { SelettoreNipotiComponent } from '../../../projectAngular/src/app/components/domandeTecniche/4_css3/selettore-nipoti/selettore-nipoti.component';

const routes: Routes = [
  { title: 'Pagina Home', path: '', component: HomeComponent },
  { title: 'Home redirect', path: 'home', redirectTo: '' },
  {
    title: 'Pagina servers',
    path: 'server',
    component: ServersComponent,
  },
  {
    title: 'variable template',
    path: 'vartemp',
    component: ViewChildVariabiliTemplateComponent,
  },
  {
    title: 'variable template',
    path: 'variable template',
    redirectTo: 'vartem',
  },
  {
    title: 'file master',
    path: 'filemaster',
    component: FileMasterComponent,
  },
  {
    title: 'for vs reduce',
    path: 'reducejs',
    component: CittaComponent,
  },
  {
    title: '2_css3',
    path: '2_css3',
    component: LayoutComponent,
  },
  {
    title: '3_css3',
    path: '3_css3',
    component: CssRobustoComponent,
  },
  {
    title: '4_css3',
    path: '4_css3',
    component: SelettoreNipotiComponent,
  },
  {
    title: 'form nomrlae vs tempalte driven vs reactive form ',
    path: 'forms',
    component: FormComponent,
  },
  { title: '404 - Page not found', path: '**', component: ErrorComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
