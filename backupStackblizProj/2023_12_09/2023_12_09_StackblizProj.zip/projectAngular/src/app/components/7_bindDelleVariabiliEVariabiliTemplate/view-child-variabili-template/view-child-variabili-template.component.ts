import {
  AfterViewInit,
  Component,
  ElementRef,
  OnInit,
  ViewChild,
} from '@angular/core';

@Component({
  selector: 'app-view-child-variabili-template',
  templateUrl: './view-child-variabili-template.component.html',
  styleUrls: ['./view-child-variabili-template.component.scss'],
})
export class ViewChildVariabiliTemplateComponent
  implements OnInit, AfterViewInit
{
  @ViewChild('testtext') text!: ElementRef;
  prova = 'testo prova';

  ngOnInit() {
    // qui non e possibile accedere perche la view e i suoi componenti non stati stati ancora creati
    console.log('ngOnInit called , text : ', this.text);
  }

  ngAfterViewInit() {
    // dopo aver inizializzato la view e possibile accedere agli elementi del DOM
    console.log(
      'ngAfterViewInit called , text : ',
      this.text.nativeElement.textContent
    );

    console.log('viewChild : ', this.text);
    console.log('viewChild : ', this.text.nativeElement.textContent);
  }

  mandaVarTemp(testo: HTMLParagraphElement) {
    console.log('testo passato tramite variabile tempalte: ', testo);
    console.log(
      'testo passato tramite variabile tempalte , textContent : ',
      testo.textContent
    );
  }
}
