import { Component, EventEmitter, Output } from '@angular/core';
import IFileItem from '../../../../../../../../projectAngular/src/app/interfaces/IFileItem';

@Component({
  selector: 'app-file-item',
  templateUrl: './file-item.component.html',
  styleUrls: ['./file-item.component.scss'],
})
export class FileItemComponent {
  @Output() emitFileItem = new EventEmitter<IFileItem>();

  oggettoDiTest: IFileItem = {
    name: 'file-item Event',
    containtsFile: 'nothing simply test',
  };

  emitEventItem() {
    this.emitFileItem.emit(this.oggettoDiTest);
  }
}
