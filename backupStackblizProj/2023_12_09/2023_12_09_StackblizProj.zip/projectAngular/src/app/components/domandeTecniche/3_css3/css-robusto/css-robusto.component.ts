import { Component } from '@angular/core';

@Component({
  selector: 'app-css-robusto',
  templateUrl: './css-robusto.component.html',
  styleUrls: ['./css-robusto.component.scss']
})
export class CssRobustoComponent {

}
