import { Component } from '@angular/core';

@Component({
  selector: 'app-selettore-nipoti',
  templateUrl: './selettore-nipoti.component.html',
  styleUrls: ['./selettore-nipoti.component.scss']
})
export class SelettoreNipotiComponent {

}
