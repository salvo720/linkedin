import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CssRobustoComponent } from './css-robusto.component';

describe('CssRobustoComponent', () => {
  let component: CssRobustoComponent;
  let fixture: ComponentFixture<CssRobustoComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CssRobustoComponent]
    });
    fixture = TestBed.createComponent(CssRobustoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
