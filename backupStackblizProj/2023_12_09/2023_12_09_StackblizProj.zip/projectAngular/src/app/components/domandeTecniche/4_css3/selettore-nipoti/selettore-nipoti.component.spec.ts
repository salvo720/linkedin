import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SelettoreNipotiComponent } from './selettore-nipoti.component';

describe('SelettoreNipotiComponent', () => {
  let component: SelettoreNipotiComponent;
  let fixture: ComponentFixture<SelettoreNipotiComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SelettoreNipotiComponent]
    });
    fixture = TestBed.createComponent(SelettoreNipotiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
