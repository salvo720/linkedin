import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { FormsModule } from '@angular/forms';
import { ErrorComponent } from './components/error/error.component';
import { HomeComponent } from './components/home/home.component';
import { RouterModule } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ServersComponent } from './components/6_decoratoreComponentEAttributoSelecotor/servers/servers.component';
import { ServerComponent } from './components/6_decoratoreComponentEAttributoSelecotor/servers/server/server.component';
import { Server2Component } from './components/6_decoratoreComponentEAttributoSelecotor/servers/server2/server2.component';
import { ViewChildVariabiliTemplateComponent } from './components/7_bindDelleVariabiliEVariabiliTemplate/view-child-variabili-template/view-child-variabili-template.component';
import { FileMasterComponent } from './components/8_comunicazioneTraComponenti/file-master/file-master.component';
import { DataFromFileMasterComponent } from './components/8_comunicazioneTraComponenti/data-from-file-master/data-from-file-master.component';
import { FileGroupComponent } from '../../../projectAngular/src/app/components/8_comunicazioneTraComponenti/file-master/file-group/file-group.component';
import { FileItemComponent } from '../../../projectAngular/src/app/components/8_comunicazioneTraComponenti/file-master/file-group/file-item/file-item.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { CittaComponent } from './components/12_forVsReduce/citta/citta.component';
import { LayoutComponent } from './components/domandeTecniche/2_css3/layout/layout.component';
import { CssRobustoComponent } from './components/domandeTecniche/3_css3/css-robusto/css-robusto.component';
import { ReactiveComponent } from './components/13_form/reactive/reactive.component';
import { TemplateDrivenComponent } from './components/13_form/template-driven/template-driven.component';
import { HtmlComponent } from './components/13_form/html/html.component';
import { FormComponent } from './components/13_form/form/form.component';
import { SelettoreNipotiComponent } from './components/domandeTecniche/4_css3/selettore-nipoti/selettore-nipoti.component';

@NgModule({
  declarations: [
    AppComponent,
    ServerComponent,
    ServersComponent,
    Server2Component,
    ErrorComponent,
    HomeComponent,
    ViewChildVariabiliTemplateComponent,
    FileGroupComponent,
    FileItemComponent,
    FileMasterComponent,
    DataFromFileMasterComponent,
    NavbarComponent,
    CittaComponent,
    LayoutComponent,
    CssRobustoComponent,
    ReactiveComponent,
    TemplateDrivenComponent,
    HtmlComponent,
    FormComponent,
    SelettoreNipotiComponent,
  ],
  imports: [BrowserModule, FormsModule, RouterModule, AppRoutingModule],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
